package com.sofi.controller;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.Controller;

import com.sofi.model.Book;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class HelloController {
	
	
	String pid[]={"bk001","bk002","bk003"};
	String pname[]={"The World OF Wars","The Heart Of Yoga","Angels And Demons"};
	String pdesc[]={"War of the Worlds is a 2005 American science fiction disaster story","a physical, mental, and spiritual practice or discipline which originated in India","Angels & Demons is a 2009 American mystery thriller"};
	String price[]={"150$","200$","350$"};
@RequestMapping("/sin")
public ModelAndView showMsg(
		@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
	
	ModelAndView mv = new ModelAndView("SignIn");
mv.addObject("msg", "hello");
	return mv;

}
@RequestMapping("/sup")
public ModelAndView showMsg1(
		@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
	
	ModelAndView mv = new ModelAndView("SignUp");

	return mv;

}
	@RequestMapping("/bsci")
	public ModelAndView showMsg2(
			@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
		
		ModelAndView mv = new ModelAndView("ImgClicked");
	
		
		mv.addObject("message", pid[0]);
		mv.addObject("name", pname[0]);
		mv.addObject("desc",pdesc[0]);
		mv.addObject("pri",price[0]);
		return mv;
		}
	@RequestMapping("/byog")
		public ModelAndView showMsg3(@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
		
		ModelAndView 	mv = new ModelAndView("ImgClicked");
		
	
		mv.addObject("message", pid[1]);
		mv.addObject("name", pname[1]);
		mv.addObject("desc",pdesc[1]);
		mv.addObject("pri",price[1]);
		return mv;
		}
	@RequestMapping("/bcon")
	public ModelAndView showMsg4(@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
	
	ModelAndView 	mv = new ModelAndView("ImgClicked");
	

	mv.addObject("message", pid[2]);
	mv.addObject("name", pname[2]);
	mv.addObject("desc",pdesc[2]);
	mv.addObject("pri",price[2]);
	return mv;
	}
	@RequestMapping("/My")
	public ModelAndView showMsg5(@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
	
	ModelAndView 	mv = new ModelAndView("My");
	mv.addObject("id", pid);
	mv.addObject("name", pname);
	mv.addObject("desc", pdesc);
	mv.addObject("pri", price);
	
	
	
	return mv;
	}
}