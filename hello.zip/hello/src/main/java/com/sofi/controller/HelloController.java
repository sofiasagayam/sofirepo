package com.sofi.controller;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.mvc.Controller;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class HelloController {
	String message="welcome to mvc...";
	@RequestMapping("/in")
public ModelAndView showMsg(
		@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
	System.out.println("in controller");
	ModelAndView 	mv = new ModelAndView("SignIn");

	mv.addObject("message", message);
	mv.addObject("name", name);
	return mv;
}
	@RequestMapping("/up")
	public ModelAndView showMsg2(
			@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
		System.out.println("in controller");
		ModelAndView 	mv = new ModelAndView("SignUp");

		mv.addObject("message", message);
		mv.addObject("name", name);
		return mv;
	}
	@RequestMapping("/img")
	public ModelAndView showMsg3(
			@RequestParam(value = "name", required = false, defaultValue = "world") String name) {
		System.out.println("in controller");
		ModelAndView 	mv = new ModelAndView("ImgClicked");

		mv.addObject("message", message);
		mv.addObject("name", name);
		return mv;
	}
	
}

/*public class HelloController implements Controller
{

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		ModelAndView mv=new ModelAndView("world");
		
		return mv;
	}
	
}*/